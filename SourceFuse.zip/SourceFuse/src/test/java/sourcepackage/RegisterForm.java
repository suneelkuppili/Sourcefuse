package sourcepackage;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class RegisterForm {

	  private WebDriver driver;
	  private StringBuffer verificationErrors = new StringBuffer();
	  
	  Connection conn ;
	  Statement st;
	  String[] region = null;
	  
	  WebElement FirstName = driver.findElement(By.xpath("//*[contains(text(),'First Name')]"));
	    WebElement FirstNameField = driver.findElement(By.xpath("//*[@id=\"fnameInput\"]/input"));
	    
	 	WebElement LastName = driver.findElement(By.xpath("//*[contains(text(),'Last Name')]"));
	 	WebElement LastNameField = driver.findElement(By.xpath("//*[@id=\"lnameInput\"]/input"));
	 	
	 	WebElement Email  = driver.findElement(By.xpath("//*[contains(text(),'Email ')]"));
	 	WebElement EmailField  = driver.findElement(By.xpath("//*[@id=\"emailInput\"]/input"));
	 	
	 	WebElement CurrentCompany = driver.findElement(By.xpath("//*[contains(text(),'Current Company ')]"));
	 	WebElement CurrentCompanyField = driver.findElement(By.xpath("//*[@id=\"curCompanyInput\"]/input"));
	 	
	 	WebElement MobileNo = driver.findElement(By.xpath("//*[contains(text(),'Mobile No. ')]"));
	 	WebElement MobileNoField = driver.findElement(By.xpath("//*[@id=\"mobInput\"]/input"));
	 	
	 	WebElement DateofBirth = driver.findElement(By.xpath("//*[contains(text(),'Date of Birth')]"));
	 	WebElement DateofBirthField = driver.findElement(By.xpath("//*[@id=\"DOBInput\"]/div/input"));
	 	
	 	WebElement Position = driver.findElement(By.xpath("//*[contains(text(),'Position you are applying for')]"));
	 	WebElement PositionField = driver.findElement(By.xpath("//*[@id=\"positionInput\"]/input"));
	 	
	 	WebElement Website = driver.findElement(By.xpath("//*[contains(text(),'Portfolio Website')]"));
	 	WebElement WebsiteField = driver.findElement(By.xpath("//*[@id=\"portfolioInput\"]/input"));
	 	
	 	WebElement Salaryrequirements = driver.findElement(By.xpath("//*[contains(text(),'Salary requirements')]"));
	 	WebElement SalaryrequirementsField = driver.findElement(By.xpath("//*[@id=\"salaryInput\"]/input"));
	 	
	 	WebElement Availability = driver.findElement(By.xpath("//*[contains(text(),'When can you start?')]"));
	 	WebElement AvailabilityField = driver.findElement(By.xpath("//*[@id=\"whenStartInput\"]/input"));
	 	
	 	WebElement Address = driver.findElement(By.xpath("//*[contains(text(),'Address')]"));
	 	WebElement AddressField = driver.findElement(By.xpath("//*[@id=\"address\"]"));
	 	
	 	WebElement Resume = driver.findElement(By.xpath("//*[contains(text(),'Upload Your Resume')]"));
	 	WebElement UploadResumepanel = driver.findElement(By.xpath("//input[@id='resume']"));
	 	
	 	WebElement Resetbutton = driver.findElement(By.xpath("//button[contains(text(),'Reset Form')]"));
	 	
	 	WebElement Relocation = driver.findElement(By.xpath("//*[contains(text(),'Are you willing to relocate?')]"));
	 	
	 	WebElement Relocationyes = driver.findElement(By.xpath("//label[contains(text(),'Yes')]"));
	 	WebElement Relocationyesrad = driver.findElement(By.xpath("//*[@id=\"yes\"]"));
	 	
	 	WebElement Relocationno = driver.findElement(By.xpath("//body/div[1]/form[1]/div[7]/div[2]/div[1]/div[1]/div[1]/label[2]"));
	 	WebElement Relocationnorad = driver.findElement(By.xpath("//*[@id=\"no\"]"));
	 	
	 	WebElement Relocationnotsure = driver.findElement(By.xpath("//label[contains(text(),'Not Sure')]"));
	 	WebElement Relocationnotsurerad = driver.findElement(By.xpath("//*[@id=\"Not Sure\"]"));    
	 	
	 	
	  @BeforeTest(alwaysRun = true)
	  public void setUp() throws Exception {
	 
	 // System Property for Chrome Driver   
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\Suneel\\eclipse-workspace\\SourceFuse\\Drivers\\Chromedriver86\\chromedriver86.exe"); 
		
	 // Instantiate a ChromeDriver class.     
	    WebDriver driver=new ChromeDriver();  
	       
	    String baseUrl = "http://sfwebhtml:t63KUfxL5vUyFLG4eqZNUcuRQ@sfwebhtml.sourcefuse.com";
	    
	    String myurl = "/automation-form-demo-for-interview/";
	    driver.navigate().to(baseUrl + myurl);  
	  }
	  
	  @AfterTest
	  public void tearDown() throws Exception {
		    driver.quit();
		    String verificationErrorString = verificationErrors.toString();
		    if (!"".equals(verificationErrorString)) {
		      Assert.fail(verificationErrorString);
		    }
		  }
	 
	  @Test
	  public void VerifyFields() throws Exception {
		 
	           
    //Maximize the browser  
        driver.manage().window().maximize();  
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    
// Submit the form without filling the data
	    
	 	driver.findElement(By.xpath("//button[contains(text(),'Submit Form')]")).click();
	    System.out.println("Form submitted without filling the fields"); 	
	 	
	 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 	
//Enter the data 	 	
	 	
	 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 	
	 	SoftAssert FN= new SoftAssert();
	 	FN.assertEquals(FirstName, "First Name");
	 	Assert.assertTrue((FirstNameField.isDisplayed()), "FirstNameField existing");
	 	FirstNameField.clear();
	 	FirstNameField.sendKeys("Suneel");	
	 	String getfirstname = FirstNameField.getAttribute("value");
	 	System.out.println("FirstNameField entered" +getfirstname);
	 	
	 	
	 	SoftAssert LN= new SoftAssert();
	 	LN.assertEquals(LastName, "Last Name");
	 	Assert.assertTrue((LastNameField.isDisplayed()), "LastNameField existing");
	 	LastNameField.clear();
	 	LastNameField.sendKeys("Kuppili");	
	 	String getlastname = LastNameField.getAttribute("value");
	 	System.out.println("LastNameField entered" +getlastname);
	 		
		
	 	SoftAssert Em= new SoftAssert();
	 	Em.assertEquals(Email, "Email");
	 	Assert.assertTrue((EmailField.isDisplayed()), "EmailField existing");
	 	EmailField.clear();
	 	EmailField.sendKeys("suneelkuppili@gmail.com");	
	 	String getemail = EmailField.getAttribute("value");
	 	System.out.println("EmailField entered" +getemail);
	 	
	 	
	 	SoftAssert CC= new SoftAssert();
	 	CC.assertEquals(CurrentCompany, "Current Company");
	 	Assert.assertTrue((CurrentCompanyField.isDisplayed()), "CurrentCompanyField existing");
	 	CurrentCompanyField.clear();
	 	CurrentCompanyField.sendKeys("suneelkuppili@gmail.com");	
	 	String getCurrentCompany = CurrentCompanyField.getAttribute("value");
	 	System.out.println("CurrentCompanyField entered" +getCurrentCompany);
	 	
	 	
	 	SoftAssert MobNo= new SoftAssert();
	 	MobNo.assertEquals(MobileNo, "Mobile No. ");
	 	Assert.assertTrue((MobileNoField.isDisplayed()), "MobileNoField existing");
	 	MobileNoField.clear();
	 	MobileNoField.sendKeys("8501808087");	
	 	String getMobileNo = MobileNoField.getAttribute("value");
	 	System.out.println("MobileNoField entered" +getMobileNo);
	 	
	 
	 	SoftAssert DOB= new SoftAssert();
	 	DOB.assertEquals(DateofBirth, "Date of Birth");
	 	Assert.assertTrue((DateofBirthField.isDisplayed()), "DateofBirthField existing");
	 	DateofBirthField.clear();
	 	DateofBirthField.sendKeys("14/08/1973");	
	 	String getDateofBirth = DateofBirthField.getAttribute("value");
	 	System.out.println("DateofBirthField entered" +getDateofBirth);
	 	
	 	
	 	SoftAssert Pos= new SoftAssert();
	 	Pos.assertEquals(Position, "Position you are applying for ");
	 	Assert.assertTrue((PositionField.isDisplayed()), "PositionField existing");
	 	PositionField.clear();
	 	PositionField.sendKeys("Automation Engineer");	
	 	String getPosition = PositionField.getAttribute("value");
	 	System.out.println("PositionField entered" +getPosition);
	 	
	 	
	 	SoftAssert Ws= new SoftAssert();
	 	Ws.assertEquals(Website, "Website");
	 	Assert.assertTrue((WebsiteField.isDisplayed()), "WebsiteField existing");
	 	WebsiteField.clear();
	 	WebsiteField.sendKeys("http://www.suneelkuppili.com");	
	 	String getWebsite = WebsiteField.getAttribute("value");
	 	System.out.println("WebsiteField entered" +getWebsite);
	 	
	 	
	 	SoftAssert salary= new SoftAssert();
	 	salary.assertEquals(Salaryrequirements, "Salary requirements");
	  	Assert.assertTrue((SalaryrequirementsField.isDisplayed()), "SalaryrequirementsField existing");
	 	SalaryrequirementsField.clear();
	 	SalaryrequirementsField.sendKeys("20 LPA");	
	 	String getSalaryrequirements = SalaryrequirementsField.getAttribute("value");
	 	System.out.println("SalaryrequirementsField entered" +getSalaryrequirements);
	 	
	 	
	 	SoftAssert Avail= new SoftAssert();
	 	Avail.assertEquals(Availability, "When can you start?");
	 	Assert.assertTrue((AvailabilityField.isDisplayed()), "AvailabilityField existing");
	 	AvailabilityField.clear();
	 	AvailabilityField.sendKeys("Immediate");	
	 	String getAvailability = AvailabilityField.getAttribute("value");
	 	System.out.println("AvailabilityField entered" +getAvailability);
	 	
	 	
	 	SoftAssert Adr= new SoftAssert();
	 	Adr.assertEquals(Address, "Address");
	 	Assert.assertTrue((AddressField.isDisplayed()), "AddressField existing");
	 	AddressField.clear();
	 	AddressField.sendKeys("804, Flat 102, MIG-II, Phase-II, KPHB");	
	 	String getAddress = AddressField.getAttribute("value");
	 	System.out.println("AddressField entered" +getAddress);
	 	
	 
	 	SoftAssert UploadRes= new SoftAssert();
	 	UploadRes.assertEquals(Resume, "Upload Your Resume ");
	 	Assert.assertTrue((UploadResumepanel.isDisplayed()), "UploadResumepanel existing");
	 	
	 	
	 	SoftAssert Relocationyeslabel= new SoftAssert();
	 	Relocationyeslabel.assertEquals(Relocationyes, "Yes");
	 	Assert.assertTrue((Relocationyesrad.isDisplayed()), "Relocation yes radio button existing");
	 	
	 	SoftAssert Relocationnolabel= new SoftAssert();
	 	Relocationnolabel.assertEquals(Relocationno, "No");
	 	Assert.assertTrue((Relocationnorad.isDisplayed()), "Relocation no radio button existing");
	 	
	 	SoftAssert Relocationnotsurelabel= new SoftAssert();
	 	Relocationnotsurelabel.assertEquals(Relocationnotsure, "Not Sure");
	 	Assert.assertTrue((Relocationnotsurerad.isDisplayed()), "Relocation not sure radio button existing");
	 	
	 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS); 	
	 	    
	 	WebElement clickonbrowse=driver.findElement(By.xpath("//*[@id=\"resume\"]"));
	 	JavascriptExecutor resume = (JavascriptExecutor)driver;
	 	resume.executeScript("arguments[0].click();",clickonbrowse );
	 	
	 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 	
		StringSelection ss = new StringSelection("D:\\DOCS & RESUMES\\Recent Resumes\\Web Automation IC.doc");
	 	
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
	 	Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	 	
	 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 	
	 	driver.switchTo().activeElement().sendKeys("ss");
	    
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 	
	 	Robot robot = new Robot();
	 	
	 	robot.keyPress(KeyEvent.VK_CONTROL);
	 	robot.keyPress(KeyEvent.VK_V);
	 	robot.keyRelease(KeyEvent.VK_V);
	 	robot.keyRelease(KeyEvent.VK_CONTROL);
	 	robot.keyPress(KeyEvent.VK_ENTER);
	 	robot.keyRelease(KeyEvent.VK_ENTER);
	 	
	 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 	
	 	driver.findElement(By.xpath("//button[contains(text(),'Submit Form')]")).click();
	 	
	 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 	
	try {

      // Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
	  // ResultSet rs = st.executeQuery("Select FirstName, LastName, Email, CurrentCompany, MobileNo, DateofBirth, Position, Website, Salaryrequirements, Availability, Address, Relocation from Sourcefuse");

		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:Mysql://localhost:3306/loginqt\",\"root\",\"suneelkuppili@123");
	    ResultSet rs = st.executeQuery("Select * from Sourcefuse");
	    Statement st = conn.createStatement();
	   	     
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    
	     while(rs.next())
	     {
	    	String dbfirstname = rs.getString("FirstName");	
	    	String dblastname = rs.getString("LastName");	
	    	String dbEmail = rs.getString("Email");	
	    	String dbCurrentCompany = rs.getString("CurrentCompany");	
	    	String dbMobileNo = rs.getString("MobileNo");	
	    	String dbDateofBirth = rs.getString("DateofBirth");	
	    	String dbPosition = rs.getString("Position");	
	    	String dbWebsite = rs.getString("Website");	
	    	String dbSalaryrequirements = rs.getString("Salaryrequirements");	
	    	String dbAvailability = rs.getString("Availability");	
	    	String dbAddress = rs.getString("Address");	
	    	String dbEmail_Sent = rs.getString("Resume");	
	    	String dbRelocation = rs.getString("Relocation");
	    
	  	
		 	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		 	
		 	Assert.assertTrue(getfirstname.equals(dbfirstname), "First name matching");	
		 	Assert.assertTrue(getlastname.equals(dblastname), "Last name matching");
		 	Assert.assertTrue(getemail.equals(dbEmail), "Email matching");
		 	Assert.assertTrue(getCurrentCompany.equals(dbCurrentCompany), "Current Company matching");
		 	Assert.assertTrue(getMobileNo.equals(dbMobileNo), "Mobile No matching");
		 	Assert.assertTrue(getDateofBirth.equals(dbDateofBirth), "DateofBirth matching");
		 	Assert.assertTrue(getPosition.equals(dbPosition), "Position matching");
		 	Assert.assertTrue(getWebsite.equals(dbWebsite), "Website matching");
		 	Assert.assertTrue(getSalaryrequirements.equals(dbSalaryrequirements), "Salaryrequirements matching");
		 	Assert.assertTrue(getAvailability.equals(dbAvailability), "Availability matching");
		 	Assert.assertTrue(getAddress.equals(dbAddress), "Address matching");
		 	Assert.assertNull(dbEmail_Sent, "Resume Not Uploaded");
		 	Assert.assertTrue((dbRelocation.equals("Yes") || dbRelocation.equals("No") || dbRelocation.equals("Not Sure") ), "Relocation Not updated");
	     
	     } 	
	     st.close();
	     conn.close();  
	  }
	catch(Exception excep)
	   {
		System.err.print("There is an Exception bro !");
		System.err.println(excep.getMessage());
	   } 
	  
	  }
/*	 	 public static void main(String[] args) throws Exception {
	 	    Connection conn = getConnection();
	 	    Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
	 	    ResultSet.CONCUR_READ_ONLY);
	 	  }
	
	 	  private static Connection getConnection() throws Exception {
	 		  Class.forName("com.mysql.jdbc.Driver");
	 		  String dburl = "jdbc:Mysql://localhost:3306/loginqt\",\"root\",\"suneelkuppili@123";
	 	    return DriverManager.getConnection(dburl);
	 	  } 	
	*/
	}

